from openai import AzureOpenAI

# Azure OpenAI client setup with provided details
azure_client = AzureOpenAI(
    api_version="2024-12-01-preview",
    azure_endpoint="https://azuse-mcbes95h-eastus2.cognitiveservices.azure.com/",
    api_key="BtS5JOB8U1ro8eZrp7FqMCaJpDtPKNuU6WGEfLKoMXMUSqgdeyMKJQQJ99BFACHYHv6XJ3w3AAAAACOGujy6"
)